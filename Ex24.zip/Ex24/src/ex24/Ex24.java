package ex24;

import java.util.Scanner;
public class Ex24 {


    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int qm;
        double pm, ptm = 0;
        
        System.out.println("Quantas macas voce comprou");
        qm = kb.nextInt();
        
        if (qm < 0) {
            System.out.println("Impossivel existir uma quantidade negativa de algo que exita, pois se algo existe ele possui um valor");
            System.out.println("Anomalia espacial detectada");
            System.out.println("Exterminar");
            System.exit(0);
        }
        
        if (qm >= 0 && qm < 12) {
            pm = 1.5;
            ptm = qm * pm;
        }   else if (qm >= 12) {
            pm = 1;
            ptm = qm * pm;
        }
        
        System.out.println("Preco a ser pago: " + ptm);
        
    }
    
}
