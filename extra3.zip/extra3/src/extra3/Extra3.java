package extra3;

import java.util.Scanner;

public class Extra3 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String senha;

        System.out.print("Informe sua senha (apenas caracteres alfabeticos / 4 caracteres apenas): ");
        senha = kb.nextLine();
        
        for (int i = 65; i <= 122; i++) {
            if ((int) senha.charAt(0) == i) {
                for (int j = 65; j <= 122; j++) {
                    if ((int) senha.charAt(1) == j) {
                        for (int k = 65; k <= 122; k++) {
                            if ((int) senha.charAt(2) == k) {
                                for (int l = 65; l <= 122; l++) {
                                    if ((int) senha.charAt(3) == l) {
                                        System.out.println("Senha: ");
                                        System.out.println("" + (char)i + (char)j + (char)k + (char)l);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }

}
