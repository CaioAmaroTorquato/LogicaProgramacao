package ex19;

import java.util.Scanner;
public class Ex19 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int a, b, c, sp;
        double A;
        
        System.out.println("Digite o valor dos lados de um triangulo");
        a = kb.nextInt();
        b = kb.nextInt();
        c = kb.nextInt();
        
        if (a <=0 || b <= 0 || c <= 0) {
            System.out.println("Valor invalido");
            System.out.println(a + " , " + b + " , " + c);
            System.exit(0);
        }
        
        if (a >= b + c || b >= a + c || c >= a + b) {
            System.out.println("Nao e possivel formar um triangulo");
            System.exit(0);
        }   else {
            sp = (a + b + c)/2;
            A = Math.sqrt(sp * (sp - a) * (sp - b) * (sp - c));
            System.out.println("Area do triangulo: " + A);
        }
        
    }
    
}
