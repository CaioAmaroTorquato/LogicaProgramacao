package enesimofor;
import java.util.Scanner;

public class EnesimoFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int enesimo, acum = 2;
        
        System.out.println("Digite um numero");
        enesimo = kb.nextInt();
        
        for(int i = 1; i <= enesimo; i++) {
            System.out.printf(acum + " - ");
            acum *= 2;
        }
    }
    
}
