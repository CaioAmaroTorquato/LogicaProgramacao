package enesimodowhile;
import java.util.Scanner;

public class EnesimoDoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int enesimo, acum = 2, quant = 1;
        
        System.out.println("Digite um numero");
        enesimo = kb.nextInt();
        
        do {
            System.out.printf(acum + " - ");
            acum *= 2;
            quant++;
        } while (quant <= enesimo);
        
    }
    
}
