package ex14;

import java.util.Scanner;
public class Ex14 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double n1, n2, n3, m;
        String tipo_m;
        
        System.out.println("Digite suas 3 notas");
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        n3 = kb.nextDouble();
        
        kb.nextLine();
        
        if (n1 < 0 || n1 > 10) {
            System.out.println("Nota invalida");
            System.exit(0);
        }
        if (n2 < 0 || n2 > 10) {
            System.out.println("Nota invalida");
            System.exit(0);
        }
        if (n3 < 0 || n3 > 10) {
            System.out.println("Nota invalida");
            System.exit(0);
        }
        
        System.out.println("Qual tipo de media voce deseja calcular? 'aritimetica' ou 'ponderada'");
        tipo_m = kb.nextLine();
        
        
        if (tipo_m.equalsIgnoreCase("Ponderada")) {
            m = (n1 * 3 + n2* 3 + n3 * 4)/10;
            System.out.println("Sua media foi de: " + m);
        }   else if (tipo_m.equalsIgnoreCase("Aritimetica")) {
            m = (n1 + n2 + n3)/3;
            System.out.println("Sua media foi de: " + m);
        }
    }
    
}
