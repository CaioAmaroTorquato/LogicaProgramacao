package ex23;

import java.util.Scanner;

public class Ex23 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int hi = 0, hf = 0, dh = 0, mi = 0, mf = 0, dm = 0;

        System.out.println("Informe o horario de inicio e fim do jogo");
        hi = kb.nextInt();
        hf = kb.nextInt();

        if (hi < 0 || hi >= 24 || hf < 0 || hf >= 24) {
            System.out.println("Hora invalida");
            System.exit(0);
        }

        System.out.println("Informe o minuto inicial e final de um jogo");
        mi = kb.nextInt();
        mf = kb.nextInt();

        if (mi < 0 || mi >= 60 || mf < 0 || mf >= 60) {
            System.out.println("Hora invalida");
            System.exit(0);
        }
        
        if (hi == hf && mi == mf) {
            dh = 24;
            dm = 0;
        }

        if (hf < hi) {
            dh = hf + 24 - hi;
        } else if (hf > hi) {
            dh = hf - hi;
        }

        if (mf < mi) {
            dm = mf + 60 - mi;
            dh -= 1;
        } else if (mf > mi) {
            dm = mf - mi;
        }
        
        if (dh > 24) {
            System.out.println("Jogo muito longo");
            System.exit(0);
        }

        System.out.println("Duracao do jogo: " + dh + "h:" + dm + "m");

    }

}
