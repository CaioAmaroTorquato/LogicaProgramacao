package tabuada0.pkg10dowhile;

public class Tabuada010doWhile {
    
    public static void main(String[] args) {
        int tabuada = 0;
                
        do {
            int numero = tabuada, multiplicador = 0;
            
            System.out.println("Tabuada do " + tabuada);
            
            while (multiplicador <= 10) {
                System.out.println(numero + " x " + multiplicador + " = " + numero * multiplicador);
                multiplicador++;
            }
            
            tabuada++;
            
        }   while (tabuada <= 10);
        
    }
    
}
