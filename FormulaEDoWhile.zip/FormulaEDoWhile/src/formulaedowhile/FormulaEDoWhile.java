package formulaedowhile;
import java.util.Scanner;

public class FormulaEDoWhile {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n, i = 1; 
        double fatorial = 1, e = 1;

        System.out.println("Informe um numero");
        n = kb.nextInt();

        do {
            fatorial *= i;
            e += 10 * i / fatorial;
            i++;
        }   while (i <= n);
        
        System.out.println(e);
    }
    
}
