package fatorialfor;
import java.util.Scanner;

public class FatorialFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int fatorial = 1, numero;
        
        System.out.println("Digite um numero para fazer o fatorial");
        numero = kb.nextInt();
        
        for (int i = 1; i <= numero; i++) {
            fatorial *= i;
        }
        
        System.out.println("Fatorial de " + numero + " eh " + fatorial);
        
    }
    
}
