package primodowhile;

import java.util.Scanner;

public class PrimoDoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int numero, i = 1, acum = 0, result = 0;

        System.out.println("Digite um numero");
        numero = kb.nextInt();

        do {
            result = numero % i;
            if (result == 0) {
                acum++;
            }
            i++;
        } while (i <= numero);

        if (acum == 2)  {
            System.out.println("Primo");
        }   else {
            System.out.println("Normal");
        }
        
    }
}
