package matriz7;

import java.util.Scanner;

public class Matriz7 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int nalunos = 40;
        int ndisciplinas = 10;
        String alunos[] = new String [nalunos];
        String disciplina [] = new String [ndisciplinas];
        double media [][] = new double [nalunos][ndisciplinas];
        int opcao;
        int i = 1;
        
        int contDisciplina = 0;
        int contAlunos = 0;
        
        int alunoSelect;
        int disciplinaSelect;
        
        while (i != 0) {
            System.out.println("1 – Cadastrar uma Disciplina");
            System.out.println("2 – Cadastrar um nome Aluno");
            System.out.println("3 – Cadastrar uma Média de aluno em disciplina");
            System.out.println("4 – Listar disciplinas;");
            System.out.println("5 – Listar alunos;");
            System.out.println("6 – listar alunos e respectiva média em determinada disciplina;");
            System.out.println("0 - Sair");
            opcao = kb.nextInt();
            
            kb.nextLine();
            
            System.out.println("------------------------------");
            
            switch (opcao) {
                //disciplina
                case 1 : {
                    System.out.println("Insira o nome da disiplina que deseja cadastrar");
                    disciplina[contDisciplina] = kb.nextLine();
                    contDisciplina++;
                    
                    System.out.println("------------------------------");
                    break;
                }
                //aluno
                case 2 : {
                    System.out.println("Insira o nome do aluno que deseja cadastrar");
                    alunos[contAlunos] = kb.nextLine();
                    contAlunos++;
                    
                    System.out.println("------------------------------");
                    break;
                }
                //media aluno em disciplina
                case 3 : {
                    System.out.println("Voce deseja cadastrar a media de qual aluno?");
                    System.out.println("Lista :");
                    
                    System.out.println(" ");
                    
                    for (int j = 0; j < contAlunos; j++) {
                        System.out.println((j + 1) + " - " + alunos[j]);
                    }
                    
                    alunoSelect = kb.nextInt();
                    alunoSelect--;
                    
                    System.out.println(" ");
                    
                    System.out.println("Voce deseja cadastrar a media do(a) " + alunos[alunoSelect] + " em qual materia?");
                    System.out.println("Lista :");
                    
                    System.out.println(" ");
                    
                    for (int j = 0; j < contDisciplina; j++) {
                        System.out.println((j + 1) + " - " + disciplina[j]);
                    }
                    
                    disciplinaSelect = kb.nextInt();
                    disciplinaSelect--;
                    
                    System.out.println(" ");
                    
                    System.out.println("Cadastre a nota do(a) " + alunos[alunoSelect] + " em " + disciplina[disciplinaSelect]);
                    media[alunoSelect][disciplinaSelect] = kb.nextDouble();
                    
                    System.out.println("------------------------------");
                    break;
                }
                //lista disciplina
                case 4 : {
                    for (int j = 0; j < contDisciplina; j++) {
                        System.out.println((j + 1) + " " + disciplina[j]);
                    }
                    
                    System.out.println("------------------------------");
                    break;
                }
                //lista alunos
                case 5 : {
                    for (int j = 0; j < contAlunos; j++) {
                        System.out.println((j + 1) + " " + alunos[j]);
                    }
                    
                    System.out.println("------------------------------");
                    break;
                }
                //lista alunos e media em disiplinas
                case 6 : {
                    for (int j = 0; j < contAlunos; j++) {
                        System.out.println(alunos[j] + " :");
                        for (int k = 0; k < contDisciplina; k++) {
                            System.out.print(disciplina[k] + " : " + media[j][k] + " ");
                        }
                        
                        System.out.println(" ");
                    }
                    
                    break;
                }
                case 0 : {
                    i = 0;
                    break;
                }
                
                default : {
                    System.out.println("Opcao invalida!");
                }
                
            }
            
        }
        
    }
    
}
