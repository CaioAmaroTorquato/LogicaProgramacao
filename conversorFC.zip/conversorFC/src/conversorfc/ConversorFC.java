package conversorfc;

import java.util.Scanner;
public class ConversorFC {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double f,c;
        System.out.println("Escreva a temperatura em Fahrenheit");
        f = teclado.nextDouble();
        c = (f-32) * 5.0/9.0;
        System.out.println("A temperatura em celcius é" + c);
        
    }
    
}
