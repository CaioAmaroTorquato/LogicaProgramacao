package extra2;

import java.util.Scanner;

public class Extra2 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String senha;
        int i = 1;
        
        int sinais[] = new int [] {33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,58,59,60,61,62,63,64,91,92,93,94,95,96,123,124,125,126};
        
        boolean sinal = false, numero = false, maiusculo = false, minusculo = false, comprimento = false;
        
        do {
            System.out.print("Cadastre sua senha: ");
            senha = kb.nextLine();
            
            for (int j = 0; j < senha.length(); j++) {
                //sinal
                for (int k = 0; k < sinais.length; k++) {
                    if ((int) senha.charAt(j) == sinais[k]) {
                        sinal = true;
                    }
                }
                
                //numero
                for (int k = 48; k <= 57; k++) {
                    if ((int) senha.charAt(j) == k) {
                        numero = true;
                    }
                }
                
                //maiusculo
                for (int k = 65; k <= 90; k++) {
                    if ((int) senha.charAt(j) == k) {
                        maiusculo = true;
                    }
                }
                
                //minusculo
                for (int k = 97; k <= 122; k++) {
                    if ((int) senha.charAt(j) == k) {
                        minusculo = true;
                    }
                }
                
            }
            
            //comprimento
            if (senha.length() >= 8) {
                comprimento = true;
            }
            
            if (sinal == true && numero == true && maiusculo == true && minusculo == true && comprimento == true) {
                System.out.println("Senha valida");
                i = 0;
            }   else {
                System.out.println("Sua senha precisa conter ao menos um sinal, um numero, um caractere maiusculo, um caractere minusculo e ao menos 8 caracteres");
            }
            
        } while (i != 0);
        
    }
    
}
