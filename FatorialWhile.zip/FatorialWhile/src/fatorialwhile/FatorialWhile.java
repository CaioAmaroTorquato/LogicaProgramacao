package fatorialwhile;
import java.util.Scanner;

public class FatorialWhile {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int fatorial = 1, numero;
        
        System.out.println("Digite um numero para fazer o fatorial");
        numero = kb.nextInt();
        
        int i = 1;
        
        while (i <= numero) {
            fatorial *= i;
            i++;
        }
        
        System.out.println("Fatorial de " + numero + " eh " + fatorial);
        
    }
    
}
