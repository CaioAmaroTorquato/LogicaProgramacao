package str2;

import java.util.Scanner;

public class Str2 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String frase;
        char vogais[] = {'a', 'e', 'i', 'o', 'u'};
        int contVogal = 0;
        
        System.out.println("Informe uma frase");
        frase = kb.nextLine();
        
        for (int i = 0; i < frase.length(); i++){
            char letra = Character.toLowerCase(frase.charAt(i));
            
            for (int j = 0; j < vogais.length; j++) {
                if (letra == vogais[j]) {
                    contVogal++;
                }
            }
        }
        
        System.out.println("Tiveram " + contVogal + " vogais");
        
    }
    
}
