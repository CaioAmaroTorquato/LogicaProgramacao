package vetorpar;

import java.util.Scanner;

public class VetorPar {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 5, i = 0, j = 0;
        int n[] = new int[tamanho];
        
        while (i < tamanho) {
            System.out.println("Informe o " + (i + 1) + "o termo");
            n[i] = kb.nextInt();
            i++;
        }
        
        i = 0;
        
        while(i < tamanho) {
            if(n[i] % 2 == 0) {
                System.out.println(n[i]);
            }
            i++;
        }
    }

}
