package subrot3;
import java.util.Scanner;

public class SubRot3 {

    static void hms (int segundos) {
        int min = segundos / 60;
        int hora = min / 60;
        if (min > 0) {
            segundos -= 60 * min;
        }
        if (hora > 0) {
            min -= 60 * hora;
        }
        
        System.out.println(hora + "h:" + min + "min:" + segundos + "sec");
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int sec;
        System.out.println("Informe um valor em segundos");
        sec = kb.nextInt();
        hms(sec);
    }
    
}
