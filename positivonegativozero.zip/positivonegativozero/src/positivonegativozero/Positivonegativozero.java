package positivonegativozero;

import java.util.Scanner;

public class Positivonegativozero {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int contPos = 0, contNeg = 0, contZero = 0, n;

        for (int i = 1; i <= 10; i++) {
            System.out.println("Digite um numero");
            n = kb.nextInt();

            if (n > 0) {
                contPos++;
            }
            if (n < 0) {
                contNeg++;
            }
            if (n == 0) {
                contZero++;
            }
        }

        System.out.println("Positivo : " + contPos);
        System.out.println("Negativo : " + contNeg);
        System.out.println("Zeros : " + contPos);

    }

}
