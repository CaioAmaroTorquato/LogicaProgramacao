package ex9;

import java.util.Scanner;

public class Ex9 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int a, b;
        
        System.out.println("Digite 2 valores inteiros");
        a = kb.nextInt();
        b = kb.nextInt();
        
        if (a % b == 0) {
            System.out.println("Sao multiplos");
        }   else if (b % a == 0) {
            System.out.println("Sao multiplos");
        }   else {
            System.out.println("Nao sao multiplos");
        }
        
    }

}
