package matriz4;

import java.util.Scanner;

public class Matriz4 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int largura = 6, altura = 3;
        String nome[] = new String[largura];
        double notas[][] = new double[largura][altura];
        double media[] = new double[largura];
        
        //entradaNome
        for (int i = 0; i < largura; i++) {
            System.out.println("Informe o nome do " + (i + 1) + "o aluno");
            nome[i] = kb.nextLine();
        }
        
        //entradaNotas
        for (int i = 0; i < largura; i++) {
            for (int j = 0; j < altura; j++) {
                System.out.println("Informe a " + (j + 1) + "a nota do " + (i + 1) + "o aluno");
                notas[i][j] = kb.nextDouble();
            }
        }
        
        //processamentoMedia
        for (int i = 0; i < largura; i++) {
            for (int j = 0; j < altura; j++) {
                media[i] += notas[i][j];
            }
            media[i] /= altura;
        }
        
        for (int i = 0; i < largura; i++) {
            System.out.println(media[i]);
        }
        
        //saida
        for (int i = 0; i < largura; i++) {
            System.out.print(nome[i] + " ");
        }
        
        for (int i = 0; i < largura; i++) {
            System.out.println(" ");
            for (int j = 0; j < altura; j++) {
                System.out.print(notas[j][i] + " ");
            }
        }
        
        for (int i = 0; i < largura; i++) {
            System.out.print(media[i] + " ");
        }
        
    }
    
}
