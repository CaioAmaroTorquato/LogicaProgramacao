package ex16;

import java.util.Scanner;
public class Ex16 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int codeP, qntP;
        double vlD;
        
        System.out.println("Informe o codigo do produto e a quantidade comprada");
        codeP = kb.nextInt();
        qntP = kb.nextInt();
        
        if (qntP < 0) {
            System.out.println("Quantidade invalida");
            System.exit(0);
        }
        
        switch (codeP) {
            case 5 -> {
                vlD = qntP * 32.00;
                System.out.println("Valor devido: R$" + vlD);
            }
            case 6 -> {
                vlD = qntP * 45.00;
                System.out.println("Valor devido: R$" + vlD);
            }
            case 2 -> {
                vlD = qntP * 37.00;
                System.out.println("Valor devido: R$" + vlD);
            }
            case 12 -> {
                vlD = qntP * 44.00;
                System.out.println("Valor devido: R$" + vlD);
            }
            default -> System.out.println("Codigo invalido");
        }
        
    }
    
}
