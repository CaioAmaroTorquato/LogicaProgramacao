package timefor;

import java.util.Scanner;

public class TimeFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int idade = 0, alturacm = 0;
        double pesokg = 0;
        String nome = "...";

        int acummenor18 = 0;
        int acummais18 = 0, acumidadesmais18 = 0;
        double mediaidademais18;

        int acumpesokg = 0;
        double porcentagempesomaisde80kg = 0;

        int acumalturacm = 0;
        double mediaalturacm = 0;
        String nomeMaior1 = "", nomeMaior2 = "", nomeMaior3 = "";
        int alturaMaior1 = -1, alturaMaior2 = -1, alturaMaior3 = -1;

        for (int i = 1; i <= 11; i++) {
            System.out.println("Informacoes jogador " + i);
            System.out.println("Informe o nome");
            nome = kb.nextLine();
            System.out.println("Informe a idade");
            idade = kb.nextInt();
            System.out.println("Informe a altura em cm");
            alturacm = kb.nextInt();
            System.out.println("Informe o peso em kg");
            pesokg = kb.nextDouble();
            kb.nextLine();

            if (alturacm > alturaMaior1) {
                alturaMaior3 = alturaMaior2;
                nomeMaior3 = nomeMaior2;
                alturaMaior2 = alturaMaior1;
                nomeMaior2 = nomeMaior1;

                alturaMaior1 = alturacm;
                nomeMaior1 = nome;
            } else if (alturacm > alturaMaior2) {
                alturaMaior3 = alturaMaior2;
                nomeMaior3 = nomeMaior2;

                alturaMaior2 = alturacm;
                nomeMaior2 = nome;
            } else if (alturacm > alturaMaior3) {
                alturaMaior3 = alturacm;
                nomeMaior3 = nome;
            }

            if (idade < 18 && idade >= 0) {
                acummenor18++;
            } else if (idade >= 18) {
                acummais18++;
                acumidadesmais18 += idade;
            }
            if (pesokg > 80) {
                acumpesokg++;
            }

            acumalturacm += alturacm;

        }

        mediaidademais18 = acumidadesmais18 / acummais18;

        porcentagempesomaisde80kg = (11 * 100) / acumpesokg;

        mediaalturacm = acumalturacm / 11;

        System.out.println("Jogadores menores de idade: " + acummenor18 + " anos");
        System.out.println("Media idade dos jogadores maiores de idade: " + mediaidademais18 + " anos");
        System.out.println("Porcentagem jogadores com mais de 80kg: " + porcentagempesomaisde80kg + "%");
        System.out.println("Altura media do time: " + mediaalturacm + " cm");
        System.out.println("Os 3 jogadores mais altos:");
        System.out.println("1) " + nomeMaior1 + " : " + alturaMaior1 + "cm");
        System.out.println("2) " + nomeMaior2 + " : " + alturaMaior2 + "cm");
        System.out.println("3) " + nomeMaior3 + " : " + alturaMaior3 + "cm");
    }

}
