package timefor;
import java.util.Scanner;

public class TimeFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int idade = 0, alturacm = 0;
        double pesokg = 0;
        String nome = "...";
        
        int acummenor18 = 0;
        int acummais18 = 0, acumidadesmais18 = 0;
        double mediaidademais18;
        
        int acumpesokg = 0;
        double porcentagempesomaisde80kg = 0;
        
        int acumalturacm = 0;
        double mediaalturacm = 0;
        
        for (int i = 1; i <= 11; i++) {
            kb.nextLine();
            System.out.println("Informacoes jogador " + i);
            System.out.println("Informe o nome");
            nome = kb.nextLine();
            System.out.println("Informe a idade");
            idade = kb.nextInt();
            System.out.println("Informe a altura em cm");
            alturacm = kb.nextInt();
            System.out.println("Informe o peso em kg");
            pesokg = kb.nextDouble();
            
            if (idade < 18 && idade >= 0) {
                acummenor18++;
            }   else if (idade >= 18) {
                acummais18++;
                acumidadesmais18 += idade;
            }
            if (pesokg > 80) {
                acumpesokg++;
            }
            
            acumalturacm += alturacm;
            
        }
        
        mediaidademais18 = acumidadesmais18 / acummais18;
        
        porcentagempesomaisde80kg = (11 * 100) / acumpesokg;
        
        mediaalturacm = acumalturacm / 11;
    }
    
}
