package vetorautobots;

import java.util.Scanner;

public class VetorAutoBots {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 5;
        String modeloC[] = new String[tamanho];
        double consumoM[] = new double[tamanho];
        double valorkm[] = new double[tamanho];
        double precoCombustivel;

        //auxiliares
        double eco1 = 0, eco2 = 0, eco3 = 0, eco4 = 0, eco5 = 0;
        String nomeeco1 = "...", nomeeco2 = "...", nomeeco3 = "...", nomeeco4 = "...", nomeeco5 = "...";

        //entrada
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o modelo do " + (i + 1) + "o modelo de carro");
            modeloC[i] = kb.nextLine();
        }
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o consumo medio do modelo: " + modeloC[i]);
            consumoM[i] = kb.nextDouble();
        }

        System.out.println("Informe o preco do combustivel");
        precoCombustivel = kb.nextDouble();

        //processamento
        //economico
        for (int i = 0; i < tamanho; i++) {
            if (consumoM[i] > eco1) {
                eco5 = eco4; nomeeco5 = nomeeco4;
                eco4 = eco3; nomeeco4 = nomeeco3;
                eco3 = eco2; nomeeco3 = nomeeco2;
                eco2 = eco1; nomeeco2 = nomeeco1;
                eco1 = consumoM[i]; nomeeco1 = modeloC[i];
            }   else if (consumoM[i] > eco2) {
                eco5 = eco4; nomeeco5 = nomeeco4;
                eco4 = eco3; nomeeco4 = nomeeco3;
                eco3 = eco2; nomeeco3 = nomeeco2;
                eco2 = consumoM[i]; nomeeco2 = modeloC[i];
            }   else if (consumoM[i] > eco3) {
                eco5 = eco4; nomeeco5 = nomeeco4;
                eco4 = eco3; nomeeco4 = nomeeco3;
                eco3 = consumoM[i]; nomeeco3 = modeloC[i];
            }   else if (consumoM[i] > eco4) {
                eco5 = eco4; nomeeco5 = nomeeco4;
                eco4 = consumoM[i]; nomeeco4 = modeloC[i];
            }   else if (consumoM[i] > eco5) {
                eco5 = consumoM[i]; nomeeco5 = modeloC[i];
            }
        }
        //780km
        for (int i = 0; i < tamanho; i++) {
            valorkm[i] = (780 / consumoM[i]) * precoCombustivel;
        }

        //saida
        System.out.println("------------------------------");
        System.out.println("Mais economico: " + nomeeco1);
        System.out.println("Menos economico : " + nomeeco5);
        System.out.println("------------------------------");
        System.out.println("Preco para fazer 780km:");
        for (int i = 0; i < tamanho; i++) {
            System.out.println(modeloC[i] + " : " + valorkm[i]);
        }
    }

}
