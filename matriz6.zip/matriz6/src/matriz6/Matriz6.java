package matriz6;

import java.util.Scanner;

public class Matriz6 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int largura = 15;
        int altura = 5;
        int min = 0, max = 0;
        int matriz[][] = new int [largura][altura];
        
        System.out.println("Em qual numero vc deseja comecar o sorteio");
        min = kb.nextInt();
        System.out.println("Em qual numero vc deseja terminar o sorteio?");
        max = kb.nextInt();
        
        if (min > max) {
            int aux = max;
            max = min;
            min = aux;
        }
        
        int n = (max - min) + 1;
        
        int repetidos[] = new int [n];
        
        for (int i = 0; i < largura; i++) {
            for (int j = 0; j < altura; j++) {
                matriz[i][j] = (int) (Math.random() * (max - min + 1)) + min;
                repetidos[matriz[i][j] - min]++;
            }
        }
        
        for (int i = 0; i < n; i++) {
            if (repetidos[i] > 1) {
                System.out.println("O numero " + (i + min) + " se repetiu " + repetidos[i] + " vezes");
            }
        }
        
    }
    
}
