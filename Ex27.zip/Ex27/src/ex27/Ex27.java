package ex27;

import java.util.Scanner;

public class Ex27 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String id, c;
        double n1, n2, n3, me, ma;

        System.out.println("Digite o codigo de identificacao do aluno");
        id = kb.nextLine();
        System.out.println("Digite as 3 notas do aluno");
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        n3 = kb.nextDouble();
        System.out.println("Digite a media dos exercicios do aluno");
        me = kb.nextDouble();

        if (n1 < 0 || n1 > 10 || n2 < 0 || n2 > 10 || n3 < 0 || n3 > 10 || me < 0 || me > 10) {
            System.out.println("Nota(s) invalida(s)");
            System.exit(1);
        }

        ma = (n1 + n2 * 2 + n3 * 3 + me) / 7;

        if (ma >= 9) {
            c = "A";
            System.out.println("ID: " + id + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media exercicios: " + me + " ;Media aproveitamento: " + ma + " ;Conceito: " + c + " ;Aprovado");
        } else if (ma >= 7.5 && ma < 9) {
            c = "B";
            System.out.println("ID: " + id + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media exercicios: " + me + " ;Media aproveitamento: " + ma + " ;Conceito: " + c + " ;Aprovado");
        } else if (ma >= 6 && ma < 7.5) {
            c = "C";
            System.out.println("ID: " + id + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media exercicios: " + me + " ;Media aproveitamento: " + ma + " ;Conceito: " + c + " ;Aprovado");
        } else if (ma >= 4 && ma < 6) {
            c = "D";
            System.out.println("ID: " + id + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media exercicios: " + me + " ;Media aproveitamento: " + ma + " ;Conceito: " + c + " ;Reprovado");
        } else if (ma < 4) {
            c = "E";
            System.out.println("ID: " + id + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media exercicios: " + me + " ;Media aproveitamento: " + ma + " ;Conceito: " + c + " ;Reprovado");
        }
    }

}
