package timedowhile;
import java.util.Scanner;

public class TimeDoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nome = "...";
        int idade = 0, alturacm = 0, i = 1, jogadores = 0;
        double pesokg = 0;
        
        //Auxiliares
        int contmenor18 = 0, contmais18 = 0, acummais18 = 0, acumaltura = 0;
        double contpesomais80 = 0, porcentagemmais80 = 0, mediaidademais18 = 0, mediaalturatime = 0;
        
        String nomeMaior1 = "", nomeMaior2 = "", nomeMaior3 = "";
        int alturaMaior1 = -1, alturaMaior2 = -1, alturaMaior3 = -1;
        
        do {
            System.out.println("Jogador " + i);
            System.out.println("--------------------");
            System.out.println("Informe o nome");
            nome = kb.nextLine();
            System.out.println("--------------------");
            System.out.println("Informe a altura em cm");
            alturacm = kb.nextInt();
            System.out.println("--------------------");
            System.out.println("Informe a idade");
            idade = kb.nextInt();
            System.out.println("--------------------");
            System.out.println("Informe o peso em kg");
            pesokg = kb.nextDouble();
            System.out.println("--------------------");
            kb.nextLine();
            
            if (alturacm > alturaMaior1) {
                alturaMaior3 = alturaMaior2;
                nomeMaior3 = nomeMaior2;
                
                alturaMaior2 = alturaMaior1;
                nomeMaior2 = nomeMaior1;
                
                alturaMaior1 = alturacm;
                nomeMaior1 = nome;
            } else if (alturacm > alturaMaior2) {
                alturaMaior3 = alturaMaior2;
                nomeMaior3 = nomeMaior2;
                
                alturaMaior2 = alturacm;
                nomeMaior2 = nome;
            } else if (alturacm > alturaMaior3) {
                alturaMaior3 = alturacm;
                nomeMaior3 = nome;
            }
            
            if (idade < 18 || idade >= 0) {
                contmenor18++;
            }   else if (idade > 18) {
                acummais18 += idade;
                contmais18++;
            }
            
            if (pesokg > 80) {
                contpesomais80++;
            }
            
            
            
            acumaltura += alturacm;
            
            jogadores++;
            i++;
        } while (i <= 11);
        
        mediaidademais18 = acummais18 / contmais18;
        
        porcentagemmais80 = (jogadores * 100) / contpesomais80;
        
        mediaalturatime = acumaltura / jogadores;
        
        System.out.println("Relatorio:");
        System.out.println("Jogadores menores de idade " + contmenor18);
        System.out.println("Media idade mais 18 " + mediaidademais18);
        System.out.println("Porcentagem dos jogadores com mais de 80kg " + porcentagemmais80);
        System.out.println("Altura media do time " + mediaalturatime);
        System.out.println("Os 3 jogadores mais altos:");
        System.out.println("1) " + nomeMaior1 + " : " + alturaMaior1 + "cm");
        System.out.println("2) " + nomeMaior2 + " : " + alturaMaior2 + "cm");
        System.out.println("3) " + nomeMaior3 + " : " + alturaMaior3 + "cm");
    }
    
}
