package a_b_c;

import java.util.Scanner;
public class A_B_C {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double a,b,c;
        
        System.out.println("Digite um número");
        a = teclado.nextDouble();
        System.out.println("Digite outro número");
        b = teclado.nextDouble();
        c = a;
        a = 0;
        a = b;
        b = 0;
        b = c;
        c = 0;
        System.out.println("A=" + a + "B=" + b);
    }
    
}
