package ex2;

import java.util.Scanner;
public class Ex2 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1;
        
        System.out.println("Digite um número");
        n1 = teclado.nextDouble();
        
        if(n1 % 6 == 0) {
            System.out.println("É divisível por 2 e 3");
        }   else {
            System.out.println("Não é fivisível por 2 ou 3");
        }
    }
    
}
