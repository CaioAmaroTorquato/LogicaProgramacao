package extra1;

import java.util.Scanner;

public class Extra1 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String senha = "Bilkitos67%", senhaInfo;
        int i = 1;
        
        do {
            System.out.print("Informe sua senha: ");
            senhaInfo = kb.nextLine();
            
            if (senhaInfo.equals(senha)) {
                System.out.println("Voce acertou sua senha");
                i = 0;
            }
            
            if (!senhaInfo.equals(senha)) {
                System.out.println("Voce errou sua senha");
            }
            
        } while (i != 0);
        
    }
    
}
