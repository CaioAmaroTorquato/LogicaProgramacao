package matriz5;

import java.util.Scanner;

public class Matriz5 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int nloja = 4;
        int nprodutos = 6;
        String lojas[] = new String[nloja];
        String produtos[] = new String[nprodutos];
        double preco[][] = new double [nloja][nprodutos];
        
        //entrada
            //lojas
        for (int i = 0; i < nloja; i++) {
            System.out.println("Informe o nome da " + (i + 1) + "a loja");
            lojas[i] = kb.nextLine();
        }
            //produtos
        for (int i = 0; i < nprodutos; i++) {
            System.out.println("Informe o numero do " + (i + 1) + "o produto");
            produtos[i] = kb.nextLine();
        }
                //preço por loja
        for (int i = 0; i < nloja; i++) {
            for (int j = 0; j < nprodutos; j++) {
                System.out.println("Informe o preco do produto " + (j + 1) + " da " + (i + 1) + "a loja");
                preco[i][j] = kb.nextDouble();
            }
        }
        
        //processamento & saida
        for (int i = 0; i < nloja; i++) {
            System.out.print(lojas[i] + " : ");
            for (int j = 0; j < nprodutos; j++) {
                if (preco[i][j] > 50) {
                    System.out.printf(preco[i][j] + " ");
                }
            }
            System.out.println(" ");
        }
        
    }
    
}
