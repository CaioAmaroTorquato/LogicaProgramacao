package subrot4;
import java.util.Scanner;

public class SubRot4 {
    
    static void lTriangulo (int l1, int l2, int l3) {
        if (l1 < l2 + l3 && l2 < l1 + l3 && l3 < l1 + l2) {
            System.out.print("Podem ser lados de um triangulo :");
            if ( l1 == l2 && l1 == l3) {
                System.out.println(" Equilatero");
            }   else if (l1 != l2 && l1 != l3 && l2 != l3) {
                System.out.println(" Escaleno");
            }   else {
                System.out.println(" Isosceles");
            }
        }   else {
            System.out.println("Nao podem ser lados de um triangulo");
        }
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n1, n2, n3;
        System.out.println("Informe 3 valores para serem os lados de um triangulo");
        n1 = kb.nextInt();
        n2 = kb.nextInt();
        n3 = kb.nextInt();
        lTriangulo(n1, n2, n3);
    }
    
}
