package primofor;
import java.util.Scanner;

public class PrimoFor {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int numero, acum = 0;
        
        System.out.println("Digite um numero");
        numero = teclado.nextInt();
        
        for(int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                acum++;
            }
        }
        
        if (acum == 2) {
            System.out.println("Primo");
        }   else {
            System.out.println("Normal");
        }
        
    }
    
}
