package com.mycompany.conversorcf;

import java.util.Scanner;

public class ConversorCF {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        double c, f;

        System.out.println("Digite a temperatura em celcius");
        c = teclado.nextDouble();
        f = (9 * c + 160) / 5;
        System.out.println("A temperatura em Fahrenheit é" + f);

    }
}
