package ex6;

import java.util.Scanner;
public class Ex6 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1,n2,n3;
        
        System.out.println("Digite 2 numeros");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        n3 = teclado.nextDouble();
        
        if(n3 < n2 && n1 < n2 ) {
            System.out.println(n3);
        }   else if(n3 < n2 && n1 < 2 && n1 < n3){
            System.out.println(n1);
        }   else {
            System.out.println(n2);
        }
    }
    
}
