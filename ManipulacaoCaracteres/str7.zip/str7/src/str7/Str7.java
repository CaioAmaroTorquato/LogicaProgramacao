package str7;

import java.util.Scanner;

public class Str7 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nomeC;
        
        System.out.println("Informe seu nome completo");
        nomeC = kb.nextLine();
        
        String nomes[] = nomeC.split(" ");
        
        for (int i = 0; i < nomes.length; i++) {
            if (i > 0 && i < (nomes.length - 1)) {
                if (nomes[i].length() == 2) {
                    System.out.print(nomes[i] + " ");
                }   else {
                    System.out.print(nomes[i].charAt(0) + ". ");
                }
            } else {
                System.out.print(nomes[i] + " ");
            }
        }
        
    }
    
}
