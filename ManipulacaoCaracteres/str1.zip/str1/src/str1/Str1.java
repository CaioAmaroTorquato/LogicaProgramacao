package str1;

import java.util.Scanner;

public class Str1 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String frase;
        
        System.out.println("Informe uma frase");
        frase = kb.nextLine();
        
        System.out.println(frase.length());
    }
    
}
