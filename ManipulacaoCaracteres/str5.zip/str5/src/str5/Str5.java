package str5;

import java.util.Scanner;

public class Str5 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String anoI;
        
        System.out.println("Informe um ano no formato dd/mm/aaaa ou dd/mm/aa");
        anoI = kb.nextLine();
        
        int ano = Integer.parseInt(anoI.split("/")[2]);
        
        ano++;
        
        System.out.println("Proximo ano : " + ano);
        
    }
    
}
