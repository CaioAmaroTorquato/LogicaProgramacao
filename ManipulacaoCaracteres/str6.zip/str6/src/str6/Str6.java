package str6;

import java.util.Scanner;

public class Str6 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nomeC;
        
        System.out.println("Informe seu nome completo");
        nomeC = kb.nextLine();
        
        String nomes[] = nomeC.split(" ");
        
        for (int i = 0; i < nomes.length; i++) {
            if (i == 0) {
                System.out.print(nomes[nomes.length - 1] + ", ");
            } else {
                System.out.print(nomes[i -1] + " ");
            }
        }
        
    }
    
}
