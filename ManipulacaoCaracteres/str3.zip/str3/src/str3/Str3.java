package str3;

import java.util.Scanner;

public class Str3 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String frase;
        
        System.out.println("Informe uma frase");
        frase = kb.nextLine();
        
        String palavras[] = frase.split(" ");
        
        System.out.println(palavras.length);
    }
    
}
