package subrot2;
import java.util.Scanner;

public class SubRot2 {

    static int entreN (int a, int b) {
        int acum = 0, menor, maior;
        if (a > b) {
            maior = a;
            menor = b;
        }   else {
            maior = b;
            menor = a;
        }
        for (int i = menor; i < maior; i++) {
            if (i > menor) {
                acum += i;
            }
        }
        
        return acum;
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n1, n2, total;
        System.out.println("Informe 2 numeros inteiros positivos");
        n1 = kb.nextInt();
        n2 = kb.nextInt();
        if (n1 < 0 || n2 < 0) {
            System.out.println("Valores invalidos");
            System.exit(0);
        }
        total = entreN(n1, n2);
        System.out.println(total);
    }
    
}
