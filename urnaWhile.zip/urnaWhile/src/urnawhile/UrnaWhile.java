package urnawhile;
import java.util.Scanner;

public class UrnaWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int votantes, opcaoVotante = 1, voto, AAA = 0, BBB = 0, CCC = 0, Nulo = 0;
        boolean votoConf = true;

        System.out.println("Sao quantos votantes");
        votantes = kb.nextInt();
        
        while (opcaoVotante <= votantes) {
            if (votoConf == true) {
                votoConf = false;
                System.out.println("Votante " + opcaoVotante);
                System.out.println("1 - Candidato AAA");
                System.out.println("2 - Candidato BBB");
                System.out.println("3 - Candidato CCC");
                System.out.println("4 - Voto nulo");

                System.out.println("Votante " + opcaoVotante + ", em quem voce deseja votar?");
                voto = kb.nextInt();

                if (voto >= 0 || voto <= 0) {
                    votoConf = true;
                }
                
                System.out.println("-----------------------------------------------");

                switch (voto) {
                    case 1: {
                        AAA++;
                        break;
                    }
                    case 2: {
                        BBB++;
                        break;
                    }
                    case 3: {
                        CCC++;
                        break;
                    }
                    case 4: {
                        Nulo++;
                        break;
                    }
                }
            }
        
            opcaoVotante++;
        }
        
        System.out.println("Quantidade de votos:");
        System.out.println("Candidato AAA: " + AAA);
        System.out.println("Candidato BBB: " + BBB);
        System.out.println("Candidato CCC: " + CCC);
        System.out.println("Nulos: " + Nulo);
        
    }
    
}
