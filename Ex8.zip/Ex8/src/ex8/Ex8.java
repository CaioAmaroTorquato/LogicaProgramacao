package ex8;

import java.util.Scanner;

public class Ex8 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double n1, n2, n3, m;

        System.out.println("Digite suas 3 notas");
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        n3 = kb.nextDouble();
        //Validacao notas
        if (n1 < 0 || n1 > 10) {
            System.out.println("Nota 1 invalida");
            System.exit(0);
        }
        if (n2 < 0 || n2 > 10) {
            System.out.println("Nota 2 invalida");
            System.exit(0);
        }
        if (n3 < 0 || n3 > 10) {
            System.out.println("Nota 3 invalida");
            System.exit(0);
        }

        m = (n1 + n2 + n3) / 3.0;

        if (m > 6.0) {
            System.out.println("Sua media: " + m + " ; Voce foi aprovado!");
        } else if (m < 6) {
            System.out.println("Sua media: " + m + " ; Voce foi reprovado!");
        }
    }

}
