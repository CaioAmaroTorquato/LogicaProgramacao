package turmafor;
import java.util.Scanner;

public class TurmaFor {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nome;
        double n1, n2, n3, n4, mediaAluno = 0, mediaTurma = 0, acumMedia = 0, contMedia = 0;
        
        for (int i = 1; i <=35; i++) {
            System.out.println("Informe o nome do aluno");
            nome = kb.nextLine();
            System.out.println("Informe as 4 notas do aluno");
            n1 = kb.nextDouble();
            n2 = kb.nextDouble();
            n3 = kb.nextDouble();
            n4 = kb.nextDouble();
            
            mediaAluno = (n1 + n2 + n3 + n4) / 4;
            
            acumMedia += mediaAluno;
            contMedia++;
            
            System.out.println("Aluno: " + nome);
            System.out.println("---------------------");
            System.out.println("Notas:");
            System.out.println(n1);
            System.out.println(n2);
            System.out.println(n3);
            System.out.println(n4);
            System.out.println("---------------------");
            System.out.println("Media:");
            System.out.println(mediaAluno);
            System.out.println("---------------------");
        }
        
        mediaTurma = acumMedia / contMedia;
        
        System.out.println("Media geral da turma:");
        System.out.println(mediaTurma);
        
    }
    
}
