package médianota7;

import java.util.Scanner;
public class Médianota7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1,n2,m;
        
        System.out.println("Digite 2 notas");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        
        m = (n1 + n2)/ 2;
        
        if (m >= 7) {
            System.out.println("Você passou, sua média foi: " + m);
        } else {
            System.out.println("Você reprovou, sua média foi: " + m);
        }
        
    }
    
}
