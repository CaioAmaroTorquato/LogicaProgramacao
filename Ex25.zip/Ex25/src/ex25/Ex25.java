package ex25;

import java.util.Scanner;
public class Ex25 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nt1, nt2, ntv = "jc";
        int gt1, gt2;
        
        System.out.println("Digite o nome e a quantidade de gols do time 1");
        nt1 = kb.nextLine();
        gt1 = kb.nextInt();
        
        if (gt1 < 0) {
            System.out.println("Quantidade de gols invalida");
            System.exit(0);
        }
        
        System.out.println("Digite o nome e a quantidade de gols do time 2");
        nt2 = kb.nextLine();
        gt2 = kb.nextInt();
        
        if (gt2 < 0) {
            System.out.println("Quantidade de gols invalida");
            System.exit(0);
        }
        
        if (gt1 == gt2) {
            System.out.println("Empate");
            System.exit(0);
        }   else if (gt1 > gt2) {
            ntv = nt1;
        }   else if (gt2 < gt1) {
            ntv = nt2;
        }   else {
            System.out.println("Paradoxo do time vencedor");
        }
        
        System.out.println("Time vencedor: " + ntv);
        
    }
    
}
