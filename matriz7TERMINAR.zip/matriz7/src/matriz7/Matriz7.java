package matriz7;

import java.util.Scanner;

public class Matriz7 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int nalunos = 40;
        int ndisciplinas = 10;
        String alunos[] = new String [nalunos];
        String disciplina [] = new String [ndisciplinas];
        double media [][] = new double [nalunos][ndisciplinas];
        int opcao;
        int i = 1;
        
        while (i != 0) {
            System.out.println("1 – Cadastrar um nome Disciplina");
            System.out.println("2 – Cadastrar um nome Aluno");
            System.out.println("3 – Cadastrar uma Média de aluno em disciplina");
            System.out.println("4 – Listar disciplinas;");
            System.out.println("5 – Listar alunos;");
            System.out.println("6 – listar alunos e respectiva média em determinada disciplina;");
            System.out.println("0 - Sair");
            opcao = kb.nextInt();
            
            switch (opcao) {
            }
            
        }
        
    }
    
}
