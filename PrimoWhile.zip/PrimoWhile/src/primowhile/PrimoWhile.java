package primowhile;
import java.util.Scanner;

public class PrimoWhile {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int numero, i = 1, acum = 0;
        
        System.out.println("Informe um numero");
        numero = kb.nextInt();
        
        while (i <= numero) {
            if (numero % i == 0) {
                acum++;
            }
            i++;
        }
        
        if (acum == 2) {
            System.out.println("Primo");
        }   else {
            System.out.println("Normal");
        }
    }
    
}
