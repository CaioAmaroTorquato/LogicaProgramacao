package coresdowhile;
import java.util.Scanner;

public class CoresDoWhile {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String cor = "...", corMais = "...";
        int quantCor, contAzul = 0, contVerde = 0, contVermelho = 0, i = 1;
        
        System.out.println("Quantas cores voce deseja informar?");
        quantCor = kb.nextInt();
        
        kb.nextLine();
        
        do {
            System.out.println("Informe a cor de numero " + i);
            cor = kb.nextLine();
            
            switch(cor.toLowerCase()){
                case "azul", "blue" : {
                    contAzul++;
                    break;
                }
                case "verde", "green" : {
                    contVerde++;
                    break;
                }
                case "vermelho", "red" : {
                    contVermelho++;
                    break;
                }
                default : {
                    System.out.println("Cor invalida");
                    break;
                }
            }
            
            i++;
        } while (i <= quantCor);
        
        if (contVermelho > contVerde && contVermelho > contAzul) {
            corMais = "Vermelho";
        }   else if (contVerde > contVermelho && contVerde > contAzul) {
            corMais = "Verde";
        }   else if (contAzul > contVermelho && contAzul > contVerde) {
            corMais = "Azul";
        }
        
        System.out.println("A cor mais digitada foi a cor " + corMais);
    }
    
}
