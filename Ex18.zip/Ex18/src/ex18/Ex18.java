package ex18;

import java.util.Scanner;
public class Ex18 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int codeC;
        double sA, sN, difS;
        
        System.out.println("Informe o codigo do cargo e seu salario");
        codeC = kb.nextInt();
        sA = kb.nextDouble();
        
        if (sA < 0) {
            System.out.println("Salario invalido");
            System.exit(0);
        }
        
        switch (codeC) {
            case 101 -> {
                sN = sA * 1.1;
                difS = sN - sA;
                System.out.println("Salario antigo: R$" + sA + " ;Salario novo: R$" + sN + " ;Diferenca: R$" + difS);
            }
            case 102 -> {
                sN = sA * 1.2;
                difS = sN - sA;
                System.out.println("Salario antigo: R$" + sA + " ;Salario novo: R$" + sN + " ;Diferenca: R$" + difS);
            }
            case 103 -> {
                sN = sA * 1.3;
                difS = sN - sA;
                System.out.println("Salario antigo: R$" + sA + " ;Salario novo: R$" + sN + " ;Diferenca: R$" + difS);
            }
            default -> {
                sN = sA * 1.4;
                difS = sN - sA;
                System.out.println("Salario antigo: R$" + sA + " ;Salario novo: R$" + sN + " ;Diferenca: R$" + difS);
            }
        }
        
    }
    
}
