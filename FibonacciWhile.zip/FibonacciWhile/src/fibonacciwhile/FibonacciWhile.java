package fibonacciwhile;

import java.util.Scanner;

public class FibonacciWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int t1 = 0, t2 = 1, numero, i = 0;

        System.out.println("Informe um numero");
        numero = kb.nextInt();

        while (i <= numero) {
            System.out.println(t1 + " ");
            int proximot = t1 + t2;
            t1 = t2;
            t2 = proximot;
            i++;
        }
    }

}
