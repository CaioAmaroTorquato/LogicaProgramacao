package vprisma;

import java.util.Scanner;
public class Vprisma {


    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double v,h,l,c;
        
        System.out.println("Digite a largura de um prisma em cm");
        l = teclado.nextDouble();
        System.out.println("Digite a altura de um prsima em cm");
        h = teclado.nextDouble();
        System.out.println("Digite o comprimento de um prisma em cm");
        c = teclado.nextDouble();
        
        v = c*l*h;
        
        System.out.println("O volume do prisma é" + v + "cm³");
        
    }
    
}
