package cantidadowhile;
import java.util.Scanner;

public class CantidaDoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int menu = 0, quantProduto = 0;
        double valor = 0, valorPago, troco, falta, a = 3.5, b = 5, c = 7.5;
        String produto;
        
        do {
            System.out.println("-------Menu-------");
            System.out.println("1 – Registrar venda de um produto");
            System.out.println("2 – Apresentar total e calcular troco");
            System.out.println("3 - Sair");
            menu = kb.nextInt();
            
            kb.nextLine();
            
            switch (menu) {
                case 1 : {
                    System.out.println("-------Produtos-------");
                    System.out.println("a – Água : R$ 3,5");
                    System.out.println("b – Salgado : R$ 5,00");
                    System.out.println("c – Salada de Frutas : R$ 7,50");
                    produto = kb.nextLine();
                    
                    switch (produto.toLowerCase()) {
                        case "a", "agua" : {
                            System.out.println("Quantos vc deseja?");
                            quantProduto = kb.nextInt();
                            
                            if (quantProduto < 0) {
                                System.out.println("Quantidade invalida");
                                System.out.println("Recalculando...");
                                quantProduto *= -1;
                            }
                            else if (quantProduto == 0) {
                                break;
                            }
                            
                            valor += a * quantProduto;
                            System.out.println("Adiciondo " + quantProduto + " agua ao carrinho");
                            break;
                        }
                        case "b", "salgado" : {
                            System.out.println("Quantos vc deseja?");
                            quantProduto = kb.nextInt();
                            
                            if (quantProduto < 0) {
                                System.out.println("Quantidade invalida");
                                System.out.println("Recalculando...");
                                quantProduto *= -1;
                            }
                            else if (quantProduto == 0) {
                                break;
                            }
                            
                            valor += b * quantProduto;
                            System.out.println("Adicionado " + quantProduto + " salgado ao carrinho");
                            break;
                        }
                        case "c", "salada de frutas" : {
                            System.out.println("Quantos vc deseja?");
                            quantProduto = kb.nextInt();
                            
                            if (quantProduto < 0) {
                                System.out.println("Quantidade invalida");
                                System.out.println("Recalculando...");
                                quantProduto *= -1;
                            }
                            else if (quantProduto == 0) {
                                break;
                            }
                            
                            valor += c * quantProduto;
                            System.out.println("Adicionado " + quantProduto + "  salada de frutas ao carrinho");
                            break;
                        }
                        default : {
                            System.out.println("Produto nao encontrado");
                            break;
                        }
                    }
                    break;
                }
                case 2 : {
                    System.out.println("-------Caixa-------");
                    System.out.println("Valor total : R$" + valor);
                    System.out.println("!Pague!");
                    valorPago = kb.nextDouble();
                    
                    if (valorPago < 0) {
                        System.out.println("!Valor invalido!");
                    }
                    if (valorPago < valor) {
                        falta = valor - valorPago;
                        valor = falta;
                        System.out.println("Falta pagar R$" + falta);
                    }
                    else if (valorPago > valor) {
                        troco = valorPago - valor;
                        System.out.println("Seu troco foi de R$" + troco);
                        menu = 3;
                    }
                    else if (valorPago == valor) {
                        menu = 3;
                    }
                    
                    if (valorPago < valor) {
                        break;
                    }
                }
                case 3 : {
                    System.out.println("Agradecemos a preferencia");
                    break;
                }
                default : {
                    System.out.println("Opcao invalida");
                    break;
                }
            }
        } while (menu != 3);
    }
    
}
