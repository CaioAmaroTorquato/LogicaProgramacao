package matriz3;

import java.util.Scanner;

public class Matriz3 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int altura = 2, largura = 2;
        int matrizUser[][] = new int[altura][largura], matriz[][] = new int [altura][largura];
        int maior = -999999999;
        
        //entrada
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                System.out.println("Preencha a primeira matriz na posicao [" + i + "][" + j + "]");
                matrizUser[i][j] = kb.nextInt();
            }
        }
        
        //processamentoMaior
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                if(matrizUser[i][j] > maior) {
                    maior = matrizUser[i][j];
                }
            }
        }
        
        //processamentoMatriz2
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                matriz[i][j] = matrizUser[i][j] * maior;
            }
        }
        
        //saida
        for (int i = 0; i < altura; i++) {
            System.out.println(" ");
            for (int j = 0; j < largura; j++) {
                System.out.print(matriz[i][j] + " ");
            }
        }
        
    }
    
}
