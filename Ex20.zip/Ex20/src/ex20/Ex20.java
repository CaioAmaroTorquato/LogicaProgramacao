package ex20;

import java.util.Scanner;
public class Ex20 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int r, n100, n50, n10, n5, n1;
        
        System.out.println("Informe o valor em reais");
        r = kb.nextInt();
        
        if (r < 0) {
            System.out.println("Valor invalido");
            System.exit(0);
        }
        
        n100 = r / 100;
        r = r % 100;
        
        n50 = r / 50;
        r = r % 50;
        
        n10 = r / 10;
        r = r % 10;
        
        n5 = r / 5;
        r = r % 5;
        
        n1 = r;
        
        System.out.println("Notas necessarias:");
        System.out.println("R$ 100: " + n100);
        System.out.println("R$  50: " + n50);
        System.out.println("R$  10: " + n10);
        System.out.println("R$   5: " + n5);
        System.out.println("R$   1: " + n1);
        
    }
    
}
