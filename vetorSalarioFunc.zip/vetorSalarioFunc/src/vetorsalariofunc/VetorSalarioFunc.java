package vetorsalariofunc;

import java.util.Scanner;

public class VetorSalarioFunc {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 5;
        String nomes[] = new String[tamanho];
        double salarios[] = new double[tamanho];
        int mesesServ[] = new int [tamanho];
        double result = 0;
        
        //entrada
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o nome do " + (i + 1) + "o funcionario");
            nomes[i] = kb.nextLine();
        }
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o salario do(a) " + nomes[i]);
            salarios[i] = kb.nextDouble();
            
            System.out.println("Inform o tempo de servico em meses do(a) " + nomes[i]);
            mesesServ[i] = kb.nextInt();
        }
        
        //processamento & saida
        System.out.println("Nao vao receber aumento");
        for (int i = 0; i < tamanho; i++) {
            if(mesesServ[i] < 60 && salarios[i] > 1940) {
                System.out.println(nomes[i]);
            }
        }
        
        System.out.println("Vao receber aumento");
        for (int i = 0; i < tamanho; i++) {
            if(mesesServ[i] > 60 || salarios[i] > 1940) {
                if(mesesServ[i] > 60 && salarios[i] > 1940) {
                    //ambos 35%
                    result = salarios[i] * 1.35;
                }
                //apenas 1
                if (mesesServ[i] > 60) {
                    //25%
                    result = salarios[i] * 1.25;
                }
                if (salarios[i] > 1940) {
                    //15%
                    result = salarios[i] * 1.15;
                }
            }
            System.out.println("Funcionario: " + nomes[i] + "; nove salario: " + salarios[i]);
        }
    }
    
}
