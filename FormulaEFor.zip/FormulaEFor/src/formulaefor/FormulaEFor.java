package formulaefor;

import java.util.Scanner;

public class FormulaEFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n; 
        double fatorial = 1, e = 1;

        System.out.println("Informe um numero");
        n = kb.nextInt();

        for (int cont = 1; cont <= n; cont++) {
            fatorial *= cont;
            e += 10 * cont / fatorial;
        }
        
        System.out.println(e);
        
    }

}
