package matriz1;

import java.util.Scanner;

public class Matriz1 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int altura = 5, largura = 5;
        int matriz[][] = new int [altura][largura];
        
        //entrada
        for (int i = 0; i < altura; i++) { 
            for (int j = 0; j < largura; j++) {
                System.out.println("Informe o valor da matriz na posicao [" + i + "][" + j + "]");
                matriz[i][j] = kb.nextInt();
            }
        }
        
        //saida
        for (int i = 0; i < altura; i++) {
            System.out.println(" ");
            for (int j = 0; j < largura; j++) {
                System.out.print(matriz[i][j] + " ");
            }
        }
    }
    
}
