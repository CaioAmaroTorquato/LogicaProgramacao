package enesimowhile;
import java.util.Scanner;

public class EnesimoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int enesimo, acum = 2, quant = 1;
        
        System.out.println("Digite um numero");
        enesimo = kb.nextInt();
        
        while(quant <= enesimo) {
            System.out.printf(acum + " - ");
            acum *= 2;
            quant++;
        }
        
    }
    
}
