package matriz2;

import java.util.Scanner;

public class Matriz2 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int altura = 3, largura = 3;
        int matriz[][] = new int [altura][largura];
        int menor = 999999999;
        
        //entrada
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                System.out.println("Informe o valor da matriz da posicao [" + i + "][" + i + "]");
                matriz[i][j] = kb.nextInt();
            }
        }
        
        //processamento
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                if(matriz[i][j] < menor) {
                    menor = matriz[i][j];
                }
            }
        }
        
        System.out.println("Menor numero:");
        System.out.println(menor);
    }
    
}
