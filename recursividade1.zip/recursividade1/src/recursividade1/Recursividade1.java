package recursividade1;

public class Recursividade1 {

    static boolean zero100 (int n) {
        if (n > 100) {
            return true;
        }
        System.out.println(n);
        return zero100(n + 1);
    }
    
    public static void main(String[] args) {
        int n = 0;
        zero100(n);
    }
    
}
