package ex26;
import java.util.Scanner;

public class Ex26 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int h1 = 0, h2 = 0, m1 = 0, m2 = 0, s = 0, p = 0;
        
        System.out.println("Digite a idade dos 2 homens e das 2 mulheres");
        h1 = kb.nextInt();
        h2 = kb.nextInt();
        m1 = kb.nextInt();
        m2 = kb.nextInt();
        
        if (h1 > h2) {
            if (m1 < m2) {
                s = h1 + m1;
                p = m2 * m2;
            }   else if (m2 < m1) {
                s = h1 + m2;
                p = m2 * m1;
            }
        }   else if (h2 > h1) {
            if (m1 < m2) {
                s = h2 + m1;
                p = m1 * m2;
            }   else if (m2 < m1) {
                s = h2 + m2;
                p = h1 * m1;
            }
        }
        
        System.out.println("Soma: " + s + " ;Produto: " + p);
        
    }
    
}
