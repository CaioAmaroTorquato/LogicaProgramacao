package ex3;

import java.util.Scanner;
public class Ex3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1;
        
        System.out.println("Digite um numero");
        n1 = teclado.nextDouble();
        
        if(n1 % 35.0 == 0) {
            System.out.println("E divsivel por 5 e por 7");
        }   else if(n1 % 5.0 == 0) {
            System.out.println("E Divisivel por 5");
        }   else if(n1 % 7.0 == 0) {
            System.out.println("E divisivel por 7");
        }   else {
            System.out.println("Nao e divisivel por 5 ou 7");
        }
        
    }
    
}
