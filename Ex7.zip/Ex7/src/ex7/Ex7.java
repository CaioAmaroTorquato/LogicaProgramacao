package ex7;

import java.util.Scanner;
public class Ex7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1, n2, n3;

        System.out.println("Digite 3 numeros");
        n1 = teclado.nextDouble();

        n2 = teclado.nextDouble();
        n3 = teclado.nextDouble();

        if (n1 <= n2 && n1 <= n3 && n2 <= n3) {
            System.out.println(n1 + " , " + n2 + " , " + n3);
        } else if (n1 <= n2 && n1 <= n3 && n3 <= n2) {
            System.out.println(n1 + " , " + n3 + " , " + n2);
        } else if (n2 <= n1 && n2 <= n3 && n1 <= n3) {
            System.out.println(n2 + " , " + n1 + " , " + n3);
        }   else if (n2 <= n1 && n2 <= n3 && n3 <= n1) {
            System.out.println(n2 + " , " + n3 + " , " + n1);
        }   else if (n3 <= n1 && n3 <= n2 && n1 <= n2) {
            System.out.println(n3 + " , " + n1 + " , " + n2);
        }   else if (n3 <= n1 && n3 <= n2 && n2 <= n1) {
            System.out.println(n3 + " , " + n2 + " , " + n1);
        }

    }

}
