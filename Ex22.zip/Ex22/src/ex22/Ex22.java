package ex22;

import java.util.Scanner;
public class Ex22 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int i;
        double a, b, c;
        
        System.out.println("Digite 3 valores");
        a = kb.nextDouble();
        b = kb.nextDouble();
        c = kb.nextDouble();
        System.out.println("Digite um modo: 1, 2, 3");
        i = kb.nextInt();
        
        switch (i) {
            case 1: {
                // a b c
                if (a >= b && b >= c) {
                    System.out.println(a + ", " + b + ", " + c);
                    break;
                }
                // a c b
                else if (a >= c && c >= b) {
                    System.out.println(a + ", " + c + ", " + b);
                    break;
                }
                // b a c
                else if (b >= a && a >= c) {
                    System.out.println(b + ", " + a + ", " + c);
                    break;
                }
                // b c a
                else if (b >= c && c >= a) {
                    System.out.println(b + ", " + c + ", " + a);
                    break;
                }
                // c a b
                else if (c >= a && a >= b) {
                    System.out.println(c + ", " + a + ", " + b);
                    break;
                }
                // c b a
                else if (c >= b && b >= a) {
                    System.out.println(c + ", " + b + ", " + a);
                    break;
                }
            }
            case 2: {
                // a b c
                if (a <= b && b <= c) {
                    System.out.println(a + ", " + b + ", " + c);
                    break;
                }
                // a c b
                else if (a <= c && c <= b) {
                    System.out.println(a + ", " + c + ", " + b);
                    break;
                }
                // b a c
                else if (b <= a && a <= c) {
                    System.out.println(b + ", " + a + ", " + c);
                    break;
                }
                // b c a
                else if (b <= c && c <= a) {
                    System.out.println(b + ", " + c + ", " + a);
                    break;
                }
                // c a b
                else if (c <= a && a <= b) {
                    System.out.println(c + ", " + a + ", " + b);
                    break;
                }
                // c b a
                else if (c <= b && b <= a) {
                    System.out.println(c + ", " + b + ", " + a);
                    break;
                }
            }
            case 3: {
                // b a c
                if (a >= b && b >= c) {
                    System.out.println(b + ", " + a + ", " + c);
                    break;
                }
                // c a b
                else if (a >= c && c >= b) {
                    System.out.println(c + ", " + a + ", " + b);
                    break;
                }
                // a b c
                else if (b >= a && a >= c) {
                    System.out.println(a + ", " + b + ", " + c);
                    break;
                }
                // c b a
                else if (b >= c && c >= a) {
                    System.out.println(c + ", " + b + ", " + a);
                    break;
                }
                // a c b
                else if (c >= a && a >= b) {
                    System.out.println(a + ", " + c + ", " + b);
                    break;
                }
                // b c a
                else if (c >= b && b >= a) {
                    System.out.println(b + ", " + c + ", " + a);
                    break;
                }
            }
            default: {
                System.out.println("Operador invalido");
                System.exit(0);
            }
            
        }
    }
    
}
