package fibonaccifor;
import java.util.Scanner;

public class FibonacciFor {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int t1 = 0, t2 = 1, numero, proximot = 0;
        
        System.out.println("Iforme um numero");
        numero = kb.nextInt();
        
        for (int i = 0; i <= numero; i++)
        {
            System.out.println(t1 + " ");
            proximot = t1 + t2;
            t1 = t2;
            t2 = proximot;
        }
    }
    
}
