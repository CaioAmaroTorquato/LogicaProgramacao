package vcilindro;

import java.util.Scanner;
public class Vcilindro {


    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double v,r,h;
        
        System.out.println("Digite o raio de um cilindro em cm");
        r = teclado.nextDouble();
        System.out.println("Digite a altura de um cilindro em cm");
        h = teclado.nextDouble();
        v = (Math.pow(h, 2)* Math.pow(r, 2));
        System.out.println("O volume do cilindro é" + v);
    }
    
}
