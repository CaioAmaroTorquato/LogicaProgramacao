package senhadowhile;

import java.util.Scanner;

public class Senhadowhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int senhaInformada;
        do {
            
            System.out.println("Digite sua senha");
            senhaInformada = kb.nextInt();
            
        } while (senhaInformada != 1234);
        
        System.out.println("Senha correta");
        
    }
}
