package fatorialdowhile;
import java.util.Scanner;

public class FatorialDoWhile {


    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int fatorial = 1, numero;
        
        System.out.println("Digite um numero para fazer o fatorial");
        numero = kb.nextInt();
        
        int i = 1;
        
        do {
            fatorial *= i;
            i++;
        } while (i <= numero);
        
        System.out.println("Fatorial de " + numero + " eh " + fatorial);
    }
    
}
