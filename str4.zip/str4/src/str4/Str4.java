package str4;

import java.util.Scanner;

public class Str4 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nomeC;
        
        System.out.println("Informe o seu nome completo");
        nomeC = kb.nextLine();
        
        System.out.println(nomeC.split(" ")[0]);
        
    }
    
}
