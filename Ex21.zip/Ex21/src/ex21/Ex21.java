package ex21;

import java.util.Scanner;
public class Ex21 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int hi, hf, d;
        
        System.out.println("Informe o horario de inicio e fim do jogo");
        hi = kb.nextInt();
        hf = kb.nextInt();
        
        if (hi < 0 || hi > 24 || hf < 0 || hf > 24) {
            System.out.println("Hora invalida");
        }
        
        if (hf <= hi) {
            d = hf + 24 - hi;
            System.out.println("Duracao: " + d + " horas");
        }   else {
            d = hf - hi;
            System.out.println("Duracao: " + d + " horas");
        }
    }
    
}
