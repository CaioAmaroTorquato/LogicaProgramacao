package recursividade4;
import java.util.Scanner;

public class Recursividade4 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double n[] = new double [5];
        
        for (int i = 0; i < n.length; i++) {
            System.out.println("Informe 1 numero");
            n[i] = kb.nextDouble();
        }
        
        double media = media(n);
        System.out.println("Media eh : " + media);
    }
    
    static double media (double n[]) {
        int media = 0;
        for (int i = 0; i < n.length; i++) {
            media += n[i];
        }
        media /= n.length;
        return media;
    }
}
