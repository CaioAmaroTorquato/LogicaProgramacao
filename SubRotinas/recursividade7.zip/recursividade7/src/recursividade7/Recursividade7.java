package recursividade7;
import java.util.Scanner;

public class Recursividade7 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int vet[] = new int [10];
        
        for (int i = 0; i < vet.length; i++) {
            System.out.println("Informe 1 numero");
            vet[i] = kb.nextInt();
        }
        
        int vetSemDup[] = semDup(vet);
        
        for (int i = 0; i < vetSemDup.length; i++) {
            System.out.println(vetSemDup[i]);
        }
    }
    
    static int[] semDup (int vet[]) {
        int semDup[];
        int maior = -999999999;
        
        for (int i = 0; i < vet.length; i++) {
            if (vet[i] > maior) {
                maior = vet[i];
            }
        }
        
        int contN[] = new int [maior + 1];
        int cont = 0;
        int posDup = 0;
        
        for (int i = 0; i < vet.length; i++) {
            contN[vet[i]]++;
        }
        for (int i = 0; i < contN.length; i++) {
            if (contN[i] != 0) {
                cont++;
            }
        }
        semDup = new int [cont];
        for (int i = 0; i < contN.length; i++) {
            if (contN[i] != 0) {
                semDup[posDup] = i;
                posDup++;
            }
        }
        
        return semDup;
    }
    
}
