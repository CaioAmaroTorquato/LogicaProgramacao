package subrot9;
import java.util.Scanner;

public class SubRot9 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nome;
        String nomeAbv[];
        System.out.println("Informe o nome completo de uma pessoa");
        nome = kb.nextLine();
        nomeAbv = abvNome(nome);
        
        for (int i = 0; i < nomeAbv.length; i++) {
            System.out.print(nomeAbv[i] + " ");
        }
    }
    static String[] abvNome (String abv) {
        String nAbv[] = abv.split(" ");
        for (int i = 0; i < nAbv.length ; i++) {
            if (nAbv[i].length() == 2 || nAbv[i].length() == 3) {
            }   else if (i > 0 && i < nAbv.length - 1) {
                nAbv[i] = Character.toUpperCase(nAbv[i].charAt(0)) + ".";
            }
        }
        
        return nAbv;
    }
    
}
