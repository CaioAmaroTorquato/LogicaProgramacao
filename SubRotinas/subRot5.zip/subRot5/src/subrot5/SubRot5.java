package subrot5;
import java.util.Scanner;

public class SubRot5 {

    static double media (double n1, double n2, double n3, char tMedia) {
        double media = 0;
        if (Character.toLowerCase(tMedia) == 'a') {
            media = (n1 + n2 + n3) / 3;
        }   else if (Character.toLowerCase(tMedia) == 'p') {
            media = (n1 * 5 + n2 * 3 + n3 * 2) / 10;
        }   else {
            System.out.println("Tipo de media invalido");
            System.exit(tMedia);
        }
        
        return media;
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double n1, n2, n3, media;
        char letra;
        
        System.out.println("Informe as 3 notas do aluno e o tipo de media desejado");
        System.out.println("A - Aritimetica");
        System.out.println("P -Ponderada");
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        n3 = kb.nextDouble();
        letra = kb.next().charAt(0);
        media = media(n1, n2, n3, letra);
        System.out.println("Media do aluno : " + media);
    }
    
}
