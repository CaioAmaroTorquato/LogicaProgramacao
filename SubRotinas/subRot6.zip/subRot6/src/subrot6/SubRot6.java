package subrot6;
import java.util.Scanner;

public class SubRot6 {

    static int durJogo (int hI, int minI, int hF, int minF) {
        int durMin = 0;
        int inicioJogo = (hI * 60) + minI;
        int fimJogo = (hF * 60) + minF;
        
        if (inicioJogo < fimJogo) {
            durMin = fimJogo - inicioJogo;
        }   else if (inicioJogo > fimJogo) {
            durMin = (1440 + fimJogo) - inicioJogo;
        }
        
        if (durMin > 1440) {
            System.out.println("Duracao invalida");
            System.exit(durMin);
        }
        
        return durMin;
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int hI, minI, hF, minF, duracao;
        System.out.println("Informe a hora e minuto de inicio de um jogo");
        hI = kb.nextInt();
        minI = kb.nextInt();
        System.out.println("Informe a hora e minuto de fim de um jogo");
        hF = kb.nextInt();
        minF = kb.nextInt();
        duracao = durJogo(hI, minI, hF, minF);
        System.out.println("Duracao em min : " + duracao + "min");
    }
    
}
