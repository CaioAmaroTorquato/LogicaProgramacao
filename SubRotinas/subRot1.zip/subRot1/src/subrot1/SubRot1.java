package subrot1;
import java.util.Scanner;

public class SubRot1 {
    
    static double mult (double a, double b) {
        double resp;
        resp = a * b;
        return resp;
    }
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double n1, n2, total;
        
        System.out.println("Informe 2 numeros para serem multiplicados");
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        total = mult(n1, n2);
        System.out.println("Multiplicacao: " + total);
    }
    
}
