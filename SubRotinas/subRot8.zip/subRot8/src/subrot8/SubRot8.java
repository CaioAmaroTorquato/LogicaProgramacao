package subrot8;
import java.util.Scanner;

public class SubRot8 {

    static void maimen (int n[]) {
        int maior = n[0];
        int menor = n[0];
        
        for (int i = 0; i < n.length; i++) {
            if (n[i] > maior) {
                maior = n[i];
            }
            if (n[i] < menor) {
                menor = n[i];
            }
        }
        
        System.out.println("Maior : " + maior);
        System.out.println("Menor : " + menor);
        
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n[] = new int [5];
        
        for (int i = 0; i < n.length; i++) {
            System.out.println("Informe um numero inteiro");
            n[i] = kb.nextInt();
        }
        maimen(n);
    }
    
}
