package subrot8;
import java.util.Scanner;

public class SubRot8 {

    static int[] maimen (int n[]) {
        int maior = n[0];
        int menor = n[0];
        int maimen[] = new int [2];
        
        for (int i = 0; i < n.length; i++) {
            if (n[i] > maior) {
                maior = n[i];
            }
            if (n[i] < menor) {
                menor = n[i];
            }
        }
        
        maimen[0] = maior;
        maimen[1] = menor;
        
        return maimen;
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n[] = new int [5];
        
        for (int i = 0; i < n.length; i++) {
            System.out.println("Informe um numero inteiro");
            n[i] = kb.nextInt();
        }
        
        int maimen[] = maimen(n);
        
        System.out.println("Maior : " + maimen[0]);
        System.out.println("Menor : " + maimen[1]);
    }
    
}
