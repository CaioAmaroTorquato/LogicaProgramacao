package reursividade2;

import java.util.Scanner;

public class Reursividade2 {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String palavra;
        System.out.println("Digite uma palavra");
        palavra = kb.nextLine();
        if (palindromo(palavra, palavra.length() - 1, "")) {
            System.out.println(palavra + " : eh palindroma");
        }   else {
            System.out.println(palavra + " : nao eh palindroma");
        }
        
    }
    
    static boolean palindromo (String palavra, int cont, String checkP) {
        if (cont < 0) {
            return false;
        }
        checkP += palavra.charAt(cont);
        if (checkP.equals(palavra)) {
            return true;
        }
        
        return palindromo (palavra, cont - 1, checkP);
    }
    
}
