package recursividade6;
import java.util.Scanner;

public class Recursividade6 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int vet[] = new int [5];
        
        for (int i = 0; i < vet.length; i++) {
            System.out.println("Informe 1 numero");
            vet[i] = kb.nextInt();
        }
        
        int RevVet[] = reverso(vet);
        
        for (int i = 0; i < RevVet.length; i++) {
            System.out.println(RevVet[i]);
        }
    }
    
    static int[] reverso (int vet[]) {
        int RevVet[] = new int [vet.length];
        int cont = vet.length - 1;
        
        for (int i = 0; i < vet.length; i++) {
            RevVet[cont] = vet[i];
            cont--;
        }
        
        return RevVet;
    }
    
}