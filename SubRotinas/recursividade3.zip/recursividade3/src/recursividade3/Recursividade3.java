package recursividade3;
import java.util.Scanner;

public class Recursividade3 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n[] = new int [5];
        for (int i = 0; i < n.length; i++) {
            System.out.println("Informe 1 numero");
            n[i] = kb.nextInt();
        }
        int maior = maior(n);
        System.out.println("Maior numero eh : " + maior);
    }
    
    static int maior (int n[]) {
        int maior = -999999999;
        for (int i = 0; i < n.length; i++) {
            if (n[i] > maior) {
                maior = n[i];
            }
        }
        return maior;
    }
    
}
