package com.mycompany.subrot7;
import java.util.Scanner;

public class SubRot7 {

    static boolean primoV (int n) {
        boolean primo = false;
        int contD = 0;
        
        for (int i = 1; i <= n; i++) {
            if (n % i == 0) {
                contD++;
            }
        }
        
        if (contD == 2 && n > 1) {
            primo = true;
        }
        
        return primo;
    }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        boolean primo;
        int n;
        System.out.println("Informe um numero");
        n = kb.nextInt();
        primo = primoV(n);
        if (primo == true) {
            System.out.println(n + " e primo");
        }   else {
            System.out.println(n + " Nao e primo");
        }
    }
}
