package recursividade5;
import java.util.Scanner;

public class Recursividade5 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int vet[] = new int [5], n;
        
        for (int i = 0; i < vet.length; i++) {
            System.out.println("Informe o " + (i + 1) + " numero do vetor");
            vet[i] = kb.nextInt();
        }
        
        System.out.println("Informe 1 numero");
        n = kb.nextInt();
        
        if (contem(vet, n)) {
            System.out.println(n + " esta presente");
        }   else {
            System.out.println(n + " nao esta presente");
        }
    }
    
    static boolean contem (int vet[], int n) {
        boolean contem = false;
        
        for (int i = 0; i < vet.length; i++) {
            if (n == vet[i]) {
                contem = true;
            }
        }
        
        return contem;
    }
    
}
