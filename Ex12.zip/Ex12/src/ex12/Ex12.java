package ex12;

import java.util.Scanner;
public class Ex12 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n1;
        
        System.out.println("Digite um numero");
        n1 = kb.nextInt();
        
        if (n1 % 2 == 0) {
            System.out.println(n1 + " eh par");
        } else if (n1 % 2 != 0) {
            System.out.println(n1 + " eh impar");
        }
    }
    
}
