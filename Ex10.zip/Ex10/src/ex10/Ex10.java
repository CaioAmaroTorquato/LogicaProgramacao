package ex10;

import java.util.Scanner;
public class Ex10 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String nome;
        int y;
        
        System.out.println("Digite o nome e a idade de um nadador");
        nome = kb.nextLine();
        y = kb.nextInt();
        
        if (y >= 5 && y <= 7) {
            System.out.println(nome + " ;Infantil A: " + y);
        }   else if (y >= 8 && y <= 10) {
            System.out.println(nome + " ;Infantil B: " + y);
        }   else if (y >= 11 && y <= 13) {
            System.out.println(nome + " ;Juvenil A: " + y);
        }   else if (y >= 14 && y <= 17) {
            System.out.println(nome + " ;Juvenil B: " + y);
        }   else if (y >= 18) {
            System.out.println(nome + " ;Adulto: " + y);
        }   else {
            System.out.println(nome + " ;Muito novo: " + y);
        }
        
    }
    
}
