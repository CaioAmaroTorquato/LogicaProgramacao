package ex11;

import java.util.Scanner;

public class Ex11 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String code;
        double n1, n2, n3, m = 0;

        System.out.println("Digite o codigo do aluno e suas 3 notas");
        code = kb.nextLine();
        n1 = kb.nextDouble();
        n2 = kb.nextDouble();
        n3 = kb.nextDouble();
        //Validacao notas
        if (n1 < 0 || n1 > 10) {
            System.out.println("Nota 1 invalida");
            System.exit(0);
        }
        if (n2 < 0 || n2 > 10) {
            System.out.println("Nota 2 invalida");
            System.exit(0);
        }
        if (n3 < 0 || n3 > 10) {
            System.out.println("Nota 3 invalida");
            System.exit(0);
        }
        //Nota maior
        if (n1 >= n2 && n1 >= n3) {
            m = (n1 * 4 + n2 * 3 + n3 * 3) / 10;
        } else if (n2 >= n1 && n2 >= n3) {
            m = (n2 * 4 + n1 * 3 + n3 * 3) / 10;
        } else if (n3 >= n1 && n3 >= n2) {
            m = (n3 * 4 + n1 * 3 + n2 * 3) / 10;
        }
        //Saida
        if (m >= 5) {
            System.out.println("Codigo: " + code + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media: " + m + " ;Aprovado");
        } else if (m < 5) {
            System.out.println("Codigo: " + code + " ;Notas: " + n1 + " , " + n2 + " , " + n3 + " ;Media: " + m + " ;Reprovado");
        }
    }

}
