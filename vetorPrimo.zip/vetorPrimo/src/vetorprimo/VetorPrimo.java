package vetorprimo;

import java.util.Scanner;

public class VetorPrimo {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 9;
        int n[] = new int [tamanho];

        for(int i = 0; i < tamanho; i++) {
            System.out.println("Informe o " + (i + 1) + "o numero");
            n[i] = kb.nextInt();
        }
        
        for(int i = 0; i < tamanho; i++) {
            int contPrimo = 0;
            for (int divisor = 1; divisor <= n[i]; divisor++) {
                if (n[i] % divisor == 0) {
                    contPrimo++;
                }
            }
            if (contPrimo == 2) {
                System.out.println(n[i]);
            }
        }
    }
    
}
