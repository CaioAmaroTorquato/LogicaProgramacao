package tabuada0.pkg10while;

public class Tabuada010while {


    public static void main(String[] args) {
        int tabuada = 0;
        
        while (tabuada <=10) {
            int numero = tabuada, multiplicador = 0;
            
            System.out.println("Tabuada do " + tabuada);
            
            while (multiplicador <= 10) {
                System.out.println(numero + " x " + multiplicador + " = " + numero * multiplicador);
                multiplicador++;
            }
            
            tabuada++;
            
        }
        
    }
    
}
