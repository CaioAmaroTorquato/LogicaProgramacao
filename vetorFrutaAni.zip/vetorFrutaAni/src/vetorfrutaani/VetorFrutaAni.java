package vetorfrutaani;

import java.util.Scanner;

public class VetorFrutaAni {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 5, tamanhoMescla = (tamanho * 2);
        String animal[] = new String[tamanho], fruta[] = new String[tamanho], mistura[] = new String [tamanhoMescla];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o " + (i + 1) + "o animal");
            animal[i] = kb.nextLine();
            System.out.println("Informe a " + (i + 1) + "a fruta");
            fruta[i] = kb.nextLine();
        }
        
        for(int i = 0; i < tamanho; i++) {
            mistura[2 * i] = animal[i];
            mistura[2 * i + 1] = fruta[i];
        }
        
        for (int i = 0; i < tamanhoMescla; i++) {
            System.out.print(mistura[i] + " - ");
        }
    }
    
}
