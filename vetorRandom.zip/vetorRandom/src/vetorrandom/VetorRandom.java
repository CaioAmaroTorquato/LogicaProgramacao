package vetorrandom;

import java.util.Scanner;

public class VetorRandom {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho100 = 100, tamanho5 = 5;
        int n100[] = new int[tamanho100], n5[] = new int[tamanho5];
        int lista;

        for (int i = 0; i < tamanho100; i++) {
            n100[i] = (int) (Math.random() * 10);
        }

        //entrada
        for (int i = 0; i < tamanho5; i++) {
            System.out.println("Informe o " + (i + 1) + "o numero de 1-10");
            n5[i] = kb.nextInt();
        }

        //processamento & saida
        for (int i = 0; i < tamanho5; i++) {
            for (int j = 0; j < tamanho100; j++) {
                if (n5[i] == n100[j]) {
                    System.out.println(n5[i] + " esta na posicao " + j);
                }
            }
        }
        
        System.out.println("Voce deseja ver a lista");
        System.out.println("1-Sim 2-Nao");
        lista = kb.nextInt();
        
        if(lista == 1) {
            for (int i = 0; i < tamanho100; i++) {
                System.out.println(n100[i]);
            }
        }   else {
            System.out.println("Ok");
        }
    }
}
