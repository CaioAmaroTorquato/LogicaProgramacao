package vetormais50;

import java.util.Scanner;

public class VetorMais50 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int tamanho = 10, i = 0;
        int n[] = new int[tamanho];
        
        do {
            System.out.println("Informe o " + (i + 1) + "o numero");
            n[i] = kb.nextInt();
            i++;
        } while(i < tamanho);
        
        i = 0;
        
        do {
            if(n[i] > 50) {
                System.out.println(n[i]);
            }
            i++;
        } while(i < tamanho);
    }
    
}
