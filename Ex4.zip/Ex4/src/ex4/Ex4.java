package ex4;

import java.util.Scanner;
public class Ex4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1,n2;
        
        System.out.println("Digite 2 numeros");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        
        if(n1 > n2) {
            System.out.println(n1);
        }   else {
            System.out.println(n2);
        }
    }
    
}
