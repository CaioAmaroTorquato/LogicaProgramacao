package ex15;

import java.util.Scanner;
public class Ex15 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double sm, sm_inv, c;
        
        System.out.println("Informe o seu saldo medio do ultimo ano");
        sm = kb.nextDouble();
        
        if (sm < 0) {
            sm_inv = sm * -1;
            System.out.println("Voce deve " + sm_inv + " para o banco");
            System.exit(0);
        }
        
        if (sm >= 0 && sm <= 200){
            c = sm * 0;
            System.out.println("Saldo medio: " + sm + " ;Credito: " + c);
        }   else if (sm >= 201 && sm <= 400) {
            c = sm * 0.2;
            System.out.println("Saldo medio: " + sm + " ;Credito: " + c);
        }   else if (sm >= 401 && sm <= 600) {
            c = sm * 0.3;
            System.out.println("Saldo medio: " + sm + " ;Credito: " + c);
        }   else if (sm >= 601) {
            c = sm * 0.4;
            System.out.println("Saldo medio: " + sm + " ;Credito: " + c);
        }
        
    }
    
}
