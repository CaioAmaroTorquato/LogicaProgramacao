package vetorautobots;

import java.util.Scanner;

public class VetorAutobots {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String automovel[] = {"forza", "uno", "eduardoEpstein"};
        double cmForza = 13, cmUno = 0.2, cmEduardoEpstein = 1;
        double cm[] = {cmForza, cmUno, cmEduardoEpstein};
        double valorC;

        System.out.println("Informe o valor do combustivel");
        valorC = kb.nextDouble();
        
        //processamento & saida
        if(cm[0] > cm[1] && cm[0] > cm[2]){
            System.out.println("Mais economico: " + automovel[0]);
        }   else if(cm[1]  > cm[0] && cm[1] > cm[2]){
            System.out.println("Mais economico: " + automovel[1]);
        }   else {
            System.out.println("Mais economico: " + automovel[2]);
        }
        
        if(cm[0] < cm[1] && cm[0] < cm[2]){
            System.out.println("Menos economico: " + automovel[0]);
        }   else if(cm[1] < cm[0] && cm[1] < cm[2]){
            System.out.println("Menos economico: " + automovel[1]);
        }   else {
            System.out.println("Menos economico: " + automovel[2]);
        }
        
        for (int i = 0; i < 3; i++) {
            System.out.println(automovel[i] + ":");
            System.out.println("Gasta " + (780 / cm[i]) + "R$ para fazer 780km");
        }
        
    }
}
