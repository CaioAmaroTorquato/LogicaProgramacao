package mediadowhile;
import java.util.Scanner;

public class MediaDoWhile {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double nR, nDigitado = 0, nMedia, nSoma = 0;
        
        do {
            
            System.out.println("Digite um numero");
            nR = kb.nextDouble();
            nDigitado++;
            
            if (nR == 0) {
                nDigitado--;
            }
            
            nSoma += nR;
            
        } while (nR != 0);
        
        nMedia = nSoma / nDigitado;
        
        System.out.println("Soma: " + nSoma + " ;Media: " + nMedia);
        
    }
    
}
