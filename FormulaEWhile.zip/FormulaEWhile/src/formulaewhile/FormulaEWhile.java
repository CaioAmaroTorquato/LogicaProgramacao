package formulaewhile;
import java.util.Scanner;

public class FormulaEWhile {
    
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n, i = 1; 
        double fatorial = 1, e = 1;

        System.out.println("Informe um numero");
        n = kb.nextInt();

        while (i <= n) {
            fatorial *= i;
            e += 10 * i / fatorial;
            i++;
        }
        
        System.out.println(e);
    }
    
}
