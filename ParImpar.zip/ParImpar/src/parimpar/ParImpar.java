package parimpar;

import java.util.Scanner;
public class ParImpar {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int z;
        
        System.out.println("Dígite um número inteiro");
        z = teclado.nextInt();
        
        if (z % 2 == 0) {
            System.out.println(z + " é par");
        } else {
            System.out.println(z + " é ímpar");
        }
    }
    
}
